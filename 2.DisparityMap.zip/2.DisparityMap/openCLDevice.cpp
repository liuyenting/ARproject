#include "opencv2/ocl/ocl.hpp"

int main(int argc, char *argv[])
{   
    cv::ocl::DevicesInfo devices;
    cv::ocl::getOpenCLDevices(devices, cv::ocl::CVCL_DEVICE_TYPE_CPU);

    return 0;
}