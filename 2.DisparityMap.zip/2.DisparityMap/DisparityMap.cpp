/**

 * @brief Get a disparity map of two images
 * @author A. Huaman
 */
#include "FlyCapture2.h"
#include <stdio.h>
#include <sstream>
#include <iostream>
#include "opencv2/calib3d/calib3d.hpp"
#include "opencv2/core/core.hpp"
#include "opencv2/imgcodecs.hpp"
#include "opencv2/highgui/highgui.hpp"
#include "opencv2/opencv.hpp"
using namespace FlyCapture2;
using namespace cv;
using namespace std;
const char *windowDisparity = "Disparity";
	Mat imageLeft,imageRight;
void PrintBuildInfo()
{
	FC2Version fc2Version;
	Utilities::GetLibraryVersion( &fc2Version );

	ostringstream version;
	version << "FlyCapture2 library version: " << fc2Version.major << "." << fc2Version.minor << "." << fc2Version.type << "." << fc2Version.build;
	cout << version.str() << endl;

	ostringstream timeStamp;
	timeStamp << "Application build date: " << __DATE__ << " " << __TIME__;
	cout << timeStamp.str() << endl << endl;
}

void PrintCameraInfo( CameraInfo* pCamInfo )
{
	cout << endl;
	cout << "*** CAMERA INFORMATION ***" << endl;
	cout << "Serial number -" << pCamInfo->serialNumber << endl;
	cout << "Camera model - " << pCamInfo->modelName << endl;
	cout << "Camera vendor - " << pCamInfo->vendorName << endl;
	cout << "Sensor - " << pCamInfo->sensorInfo << endl;
	cout << "Resolution - " << pCamInfo->sensorResolution << endl;
	cout << "Firmware version - " << pCamInfo->firmwareVersion << endl;
	cout << "Firmware build time - " << pCamInfo->firmwareBuildTime << endl << endl;


}

int main( int argc, char** argv )
{ 
  
    PrintBuildInfo();
    BusManager busMgr;
    unsigned int numCameras;
    char result[20]; int n=0;
    busMgr.GetNumOfCameras(&numCameras);
    Camera** ppCameras = new Camera*[numCameras];
    for ( unsigned int i = 0; i < numCameras; i++){
		ppCameras[i] = new Camera();
		PGRGuid guid;
		busMgr.GetCameraFromIndex( i, &guid );
		// Connect to a camera
		ppCameras[i]->Connect( &guid );
		// Get the camera information
		CameraInfo camInfo;
		ppCameras[i]->GetCameraInfo( &camInfo );
		PrintCameraInfo(&camInfo);
		ppCameras[i]->SetVideoModeAndFrameRate(	VIDEOMODE_1600x1200RGB,FRAMERATE_15 );
	}
	
    char key = 0;
    ppCameras[1]->StartCapture();
    ppCameras[0]->StartCapture();	    
    while(key != 'q'){
        // Get the image
               Image rawImage;
	       Image rawImage1;
               ppCameras[1]->RetrieveBuffer( &rawImage1 );
               ppCameras[0]->RetrieveBuffer( &rawImage );
	// convert to rgb
              Image rgbImage;Image rgbImage1;
              rawImage.Convert( FlyCapture2::PIXEL_FORMAT_BGR, &rgbImage );
	      rawImage1.Convert( FlyCapture2::PIXEL_FORMAT_BGR, &rgbImage1 );
        // convert to OpenCV Mat
              unsigned int rowBytes = (double)rgbImage.GetReceivedDataSize()/(double)rgbImage.GetRows();       
              imageLeft = cv::Mat(rgbImage.GetRows(), rgbImage.GetCols(), CV_8UC3, rgbImage.GetData(),rowBytes);
		unsigned int rowBytes1 = (double)rgbImage1.GetReceivedDataSize()/(double)rgbImage1.GetRows();       
               imageRight = cv::Mat(rgbImage1.GetRows(), rgbImage1.GetCols(), CV_8UC3, rgbImage1.GetData(),rowBytes1);
         
	       if( argc == 3 ){ 
		 imageLeft=imread(argv[1],IMREAD_GRAYSCALE);
		 imageRight=imread(argv[2],IMREAD_GRAYSCALE); 
		 
	      }
	      else{  
		cvtColor( imageLeft, imageLeft, CV_BGR2GRAY );
	       cvtColor( imageRight, imageRight, CV_BGR2GRAY );
	      
		}   
		resize(imageLeft, imageLeft, cv::Size(640, 480));
        	resize(imageRight, imageRight, cv::Size(640, 480));
	   
		imshow("Cameraright", imageRight);
	        imshow("Cameraleft", imageLeft);
	          
              Mat imgDisparity16S = Mat( imageLeft.rows, imageLeft.cols, CV_16S );
              Mat imgDisparity8U = Mat( imageRight.rows, imageRight.cols, CV_8UC1 );
              //-- 3. Calculate the disparity image
	      int cn = imageLeft.channels();
              int ndisparities = 16*5;   /**< Range of disparity */
              int SADWindowSize = 21; /**< Size of the block window. Must be odd */ 
          /*  Ptr<StereoSGBM> sgbm = StereoSGBM::create(0,16,3);
	      sgbm->setPreFilterCap(31);
              int sgbmWinSize =  9;
              sgbm->setBlockSize(sgbmWinSize);
              sgbm->setP1(4*cn*sgbmWinSize*sgbmWinSize);
              sgbm->setP2(32*cn*sgbmWinSize*sgbmWinSize);
              sgbm->setMinDisparity(-100);
	      sgbm->setNumDisparities(256);
	      sgbm->setUniquenessRatio(25);
	      sgbm->setSpeckleWindowSize(100);
	      sgbm->setSpeckleRange(50);
	      sgbm->setDisp12MaxDiff(1);
	      sgbm->setMode(StereoSGBM::MODE_SGBM);*/
             Ptr<StereoSGBM> sgbm = StereoSGBM::create(10,    //int minDisparity
                                        96,     //int numDisparities
                                        5,      //int SADWindowSize
                                        600,    //int P1 = 0
                                        2400,   //int P2 = 0
                                        20,     //int disp12MaxDiff = 0
                                        31,     //int preFilterCap = 0
                                        3,      //int uniquenessRatio = 0
                                        100,    //int speckleWindowSize = 0
                                        20,     //int speckleRange = 0
                                        true);  //bool fullDP = false

	    sgbm->compute( imageLeft, imageRight, imgDisparity16S );
             //-- Check its extreme values
               double minVal; double maxVal;
               minMaxLoc( imgDisparity16S, &minVal, &maxVal );
	  
             //-- 4. Display it as a CV_8UC1 image
             imgDisparity16S.convertTo( imgDisparity8U, CV_8UC1, 255/(maxVal - minVal));
	       namedWindow( windowDisparity, WINDOW_NORMAL );
              imshow( windowDisparity, imgDisparity8U );
	      
	      
	      switch (key) {
			case 'q':
			case 'Q':
			case 27:	// escape key
				return 0;
			case ' ':	// Save image
        		sprintf(result,"left%.2d.jpg", n++);
                        imwrite(result,imgDisparity8U);
			
        		cout << "Saved " << result << endl;
        		break;
			default:
				break;
		}
	      
	    waitKey(3);
	    }

	    waitKey(0);

  return 0;
}

/**
 * @function readme
 */
void readme()
{ std::cout << " Usage: ./disparity <imgLeft> <imgRight>" << std::endl; }
