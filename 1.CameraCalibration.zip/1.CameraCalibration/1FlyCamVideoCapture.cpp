

#include "FlyCapture2.h"
#include <iostream>
#include <sstream>
#include <opencv2/core/core.hpp>
#include <opencv2/highgui/highgui.hpp>
#include "opencv2/opencv.hpp"
using namespace FlyCapture2;
using namespace std;
using namespace cv;


void PrintBuildInfo()
{
	FC2Version fc2Version;
	Utilities::GetLibraryVersion( &fc2Version );

	ostringstream version;
	version << "FlyCapture2 library version: " << fc2Version.major << "." << fc2Version.minor << "." << fc2Version.type << "." << fc2Version.build;
	cout << version.str() << endl;

	ostringstream timeStamp;
	timeStamp << "Application build date: " << __DATE__ << " " << __TIME__;
	cout << timeStamp.str() << endl << endl;
}

void PrintCameraInfo( CameraInfo* pCamInfo )
{
	cout << endl;
	cout << "*** CAMERA INFORMATION ***" << endl;
	cout << "Serial number -" << pCamInfo->serialNumber << endl;
	cout << "Camera model - " << pCamInfo->modelName << endl;
	cout << "Camera vendor - " << pCamInfo->vendorName << endl;
	cout << "Sensor - " << pCamInfo->sensorInfo << endl;
	cout << "Resolution - " << pCamInfo->sensorResolution << endl;
	cout << "Firmware version - " << pCamInfo->firmwareVersion << endl;
	cout << "Firmware build time - " << pCamInfo->firmwareBuildTime << endl << endl;


}





int main(int /*argc*/, char** /*argv*/){
	PrintBuildInfo();
	
	BusManager busMgr;
	unsigned int numCameras;
	 busMgr.GetNumOfCameras(&numCameras);
        cout << "\nThe number of camera=" << numCameras;

	if ( numCameras < 1 )
	{
		cout << "Insufficient number of cameras... press Enter to exit." << endl; ;
		cin.ignore();
		return -1;
	}

	Camera** ppCameras = new Camera*[numCameras];

	// Connect to all detected cameras and attempt to set them to
	// a common video mode and frame rate
	for ( unsigned int i = 0; i < numCameras; i++)
	{
		ppCameras[i] = new Camera();

		PGRGuid guid;
		busMgr.GetCameraFromIndex( i, &guid );
		
		// Connect to a camera
		ppCameras[i]->Connect( &guid );
		
		// Get the camera information
		CameraInfo camInfo;
		ppCameras[i]->GetCameraInfo( &camInfo );
		

		PrintCameraInfo(&camInfo);
	
		// Set all cameras to a specific mode and frame rate so they
		// can be synchronized
	ppCameras[i]->SetVideoModeAndFrameRate(
				VIDEOMODE_1600x1200RGB,
				FRAMERATE_15 );
		
	}
	
	
	char filenameL[200], filenameR[200];
	if (numCameras<3){
	
       ppCameras[1]->StartCapture();
	
       ppCameras[0]->StartCapture();
	 
	char key = 0;

 
   VideoWriter videoL("LeftVideo.avi",CV_FOURCC('M','J','P','G'),10, Size(640,480),true);
   VideoWriter videoR("RightVideo.avi",CV_FOURCC('M','J','P','G'),10, Size(640,480),true);
   int n=1;
	while(key != 'q'){
        // Get the image
        Image rawImage;
	Image rawImage1;
      ppCameras[1]->RetrieveBuffer( &rawImage );
    
      ppCameras[0]->RetrieveBuffer( &rawImage1 );
    

        // convert to rgb
        Image rgbImage;Image rgbImage1;
        rawImage.Convert( FlyCapture2::PIXEL_FORMAT_BGR, &rgbImage );
	rawImage1.Convert( FlyCapture2::PIXEL_FORMAT_BGR, &rgbImage1 );

        // convert to OpenCV Mat
        unsigned int rowBytes = (double)rgbImage.GetReceivedDataSize()/(double)rgbImage.GetRows();       
        cv::Mat image = cv::Mat(rgbImage.GetRows(), rgbImage.GetCols(), CV_8UC3, rgbImage.GetData(),rowBytes);
	
	unsigned int rowBytes1 = (double)rgbImage1.GetReceivedDataSize()/(double)rgbImage1.GetRows();       
        cv::Mat image1 = cv::Mat(rgbImage1.GetRows(), rgbImage1.GetCols(), CV_8UC3, rgbImage1.GetData(),rowBytes1);

	cv::resize(image,image, cv::Size(640, 480));
	cv::resize(image1,image1, cv::Size(640, 480));
		
        cv::imshow("Cameraright", image);
	cv::imshow("Cameraleft", image1);


        key = cv::waitKey(30);  
        videoL.write(image);
        videoR.write(image1);
	switch (key) {
			case 'q':
			case 'Q':
			case 27:	// escape key
				return 0;
			case ' ':	// Save image
        		sprintf(filenameL,"left%.2d.jpg", n);
                imwrite(filenameL,image1);
			sprintf(filenameR,"right%.2d.jpg",n++);
                imwrite(filenameR,image);
        		cout << "Saved " << filenameL << " " << filenameR << endl;
        		break;
			default:
				break;
		}

      
        }

  
	}


	ppCameras[1]->Disconnect();
	 
	

	
	delete [] ppCameras;

	cout << "Done! Press Enter to exit..." << endl;
	cin.ignore();

	return 0;

}
