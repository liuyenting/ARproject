/*this creates a yaml or xml list of files from the command line args
 */
// ./imagelist_creator [number of pair image]

#include "opencv2/core/core.hpp"
#include "opencv2/highgui/highgui.hpp"
#include <string>
#include <iostream>
#include <stdio.h>

using std::string;
using std::cout;
using std::endl;

using namespace cv;

static void help(char** av)
{
  cout << "\nThis creates a yaml or xml list of files from the command line args\n"
      "usage:\n./" << av[0] << " imagelist.yaml *.png\n"
      << "Try using different extensions.(e.g. yaml yml xml xml.gz etc...)\n"
      << "This will serialize this list of images or whatever with opencv's FileStorage framework" << endl;
}

int main(int ac, char** av)
{

  string outputname = "stereo_calib.xml";
  char filenameL[100], filenameR[100];
  FileStorage fs(outputname, FileStorage::WRITE);
  fs << "imagelist" << "[";
  for(int i = 1; i < atoi(av[1]); i++){
    sprintf(filenameL,"left%.2d.jpg", i);
     sprintf(filenameR,"right%.2d.jpg", i);
    
    fs << filenameL;
    fs << filenameR;
  }
  fs << "]";
  return 0;
}
