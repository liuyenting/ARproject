/*this creates a yaml or xml list of files from the command line args
 */

#include "opencv2/core/core.hpp"
#include "opencv2/highgui/highgui.hpp"
#include <string>
#include <iostream>
#include <stdio.h>

using std::string;
using std::cout;
using std::endl;

using namespace cv;

static void help(char** av)
{
  cout << "\nThis creates a yaml or xml list of files from the command line args\n"
      "usage:\n./" << av[0] << " imagelist.yaml *.png\n"
      << "Try using different extensions.(e.g. yaml yml xml xml.gz etc...)\n"
      << "This will serialize this list of images or whatever with opencv's FileStorage framework" << endl;
}

int main(int ac, char** av)
{
  if (ac < 3)
  {
    help(av);
    return 1;
  }

  string outputname = av[1];
  char filenameL[100], filenameR[100];
  Mat m = imread(outputname); //check if the output is an image - prevent overwrites!
  if(!m.empty()){
    std::cerr << "fail! Please specify an output file, don't want to overwrite you images!" << endl;
    help(av);
    return 1;
  }

  FileStorage fs(outputname, FileStorage::WRITE);
  fs << "imagelist" << "[";
  for(int i = 1; i < atoi(av[2]); i++){
    sprintf(filenameL,"\"left%.2d.jpg\"", i);
     sprintf(filenameR,"right%.2d.jpg", i);
    
    fs << filenameL;
    fs << filenameR;
  }
  fs << "]";
  return 0;
}
