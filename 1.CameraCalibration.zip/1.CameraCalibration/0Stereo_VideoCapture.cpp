// inputL inputR OR
// inputL inputR outputL outputR
// 0 1 VideoL.avi VideoR.avi 

#include "opencv2/highgui/highgui.hpp"
#include "opencv2/imgproc/imgproc.hpp"
#include <iostream>
#include <vector>
#include <stdio.h>

using namespace cv;
using namespace std;

int capture(VideoCapture& captureL, VideoCapture& captureR) 
{
   	int n = 1;
   	char filenameL[200], filenameR[200];
	string windowL_name = "Video(Left)";
	string windowR_name = "Video(Right)";
	
	Mat frameL, frameR;

	cout << "press space to save a picture. q or esc to quit" << endl;
	namedWindow(windowL_name, 1);
	namedWindow(windowR_name, 1);

	for (;;) {
		captureL >> frameL;
		captureR >> frameR;
		
		if (frameL.empty() || frameR.empty())
			continue;

		imshow(windowL_name, frameL);
		imshow(windowR_name, frameR);

		char key = (char)waitKey(1); //delay N millis, to display and capture input
		switch (key) {
			case 'q':
			case 'Q':
			case 27:	// escape key
				return 0;
			case ' ':	// Save image
        		sprintf(filenameL,"left%.2d.jpg", n);
        		imwrite(filenameL,frameL);
				sprintf(filenameR,"right%.2d.jpg",n++);
        		imwrite(filenameR,frameR);
        		cout << "Saved " << filenameL << " " << filenameR << endl;
        		break;
			default:
				break;
		}
	}
	return 0;
}

int captureWrite(VideoCapture& captureL, VideoCapture& captureR, VideoWriter& outCaptureL, VideoWriter& outCaptureR) 
{
   	int n = 1;
   	char filenameL[200], filenameR[200];
	string windowL_name = "Video(Left)";
	string windowR_name = "Video(Right)";
	
	Mat frameL, frameR;

	cout << "press space to save a picture. q or esc to quit" << endl;
	namedWindow(windowL_name, 1);
	namedWindow(windowR_name, 1);

	for (;;) {
		captureL >> frameL;
		captureR >> frameR;
		
		if (frameL.empty() || frameR.empty())
			continue;
		
		outCaptureL << frameL;
		outCaptureR << frameR;

		imshow(windowL_name, frameL);
		imshow(windowR_name, frameR);

		char key = (char)waitKey(1); //delay N millis, to display and capture input
		switch (key) {
			case 'q':
			case 'Q':
			case 27:	//escape key
				return 0;
			case ' ': //Save an image
        		sprintf(filenameL,"left%.2d.jpg", n);
        		imwrite(filenameL,frameL);
				sprintf(filenameR,"right%.2d.jpg",n++);
        		imwrite(filenameR,frameR);
        		cout << "Saved " << filenameL << " " << filenameR << endl;
        		break;
			default:
				break;
		}
	}
	captureL.release();
	captureR.release();
	outCaptureL.release();
	outCaptureR.release();
	return 0;
}

int main(int argc, char** argv) {

    if (argc!=3 && argc!=5) {
        cerr << "Invalid no. of arguments (should b 3 or 5)!" << endl;
        return 1;
    }
	 
	std::string argL = argv[1];
    VideoCapture captureL(argL);	
    if (!captureL.isOpened())		
        captureL.open(atoi(argL.c_str()));
    if (!captureL.isOpened()) {
        cerr << "Failed to open a video device or video file for input!\n" << endl;
        return 1;
    }
   std::string argR = argv[2];
    VideoCapture captureR(argR);	// try to open as a video file (string)
    if (!captureR.isOpened())		// try to open as a video camera (int)
        captureR.open(atoi(argR.c_str()));
    if (!captureR.isOpened()) {
        cerr << "Failed to open a video device or video file for input!\n" << endl;
        return 1;
    }

	if (argc==3)
		return capture(captureL,captureR);
	else
	{

		VideoWriter outCapL(argv[3],	
               CV_FOURCC('M','J','P','G'),	//captureL.get(CV_CAP_PROP_FOURCC),
			   30,					//captureL.get(CV_CAP_PROP_FPS),
               Size(640,480));		//Size(captureL.get(CV_CAP_PROP_FRAME_WIDTH),captureL.get(CV_CAP_PROP_FRAME_HEIGHT)));

		VideoWriter outCapR(argv[4],	
               CV_FOURCC('M','J','P','G'),	//captureL.get(CV_CAP_PROP_FOURCC),
			   30,					//captureL.get(CV_CAP_PROP_FPS),
               Size(640,480));		//Size(captureL.get(CV_CAP_PROP_FRAME_WIDTH),captureL.get(CV_CAP_PROP_FRAME_HEIGHT)));

		if (!outCapL.isOpened()) {
		    cerr << "Failed to open output video!" << std::endl;
			return 1;
		}
	
		if (!outCapR.isOpened()) {
		    cerr << "Failed to open output video!" << std::endl;
			return 1;
		}

		return captureWrite(captureL, captureR, outCapL, outCapR);
	}
}
